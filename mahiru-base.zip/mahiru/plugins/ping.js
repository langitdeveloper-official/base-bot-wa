exports.command = ['ping2', 'cek']
exports.tags    = ['kon']
exports.desc    = 'Cek respon bot'

exports.handler = async ({ m, Reply, time }) => {
  Reply(`🏓 Pong!\nWaktu: ${time}`)
}
