require('./Settings/config')

const {
    default: baileys,
    proto,
    jidNormalizedUser,
    generateWAMessage,
    generateWAMessageFromContent,
    getContentType,
    prepareWAMessageMedia
} = require("@whiskeysockets/baileys");

const fs      = require('fs')
const util    = require('util')
const chalk   = require('chalk')
const os      = require('os')
const jimp    = require("jimp")
const axios   = require('axios')
const fsx     = require('fs-extra')
const crypto  = require('crypto')
const path    = require('path')
const ffmpeg  = require('fluent-ffmpeg')
const speed   = require('performance-now')
const timestampp = speed()
const latensi = speed() - timestampp
const moment  = require('moment-timezone')
const { spawn, exec, execSync } = require('child_process')

const {
    smsg, tanggal, getTime, isUrl, sleep,
    clockString, runtime, fetchJson, getBuffer,
    jsonformat, format, parseMention, getRandom,
    getGroupAdmins, generateProfilePicture
} = require('./lib/storage')

const {
    imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif
} = require('./lib/exif')

module.exports = LangitDev = async (LangitDev, m, chatUpdate, store) => {
    try {
        const body = (
            m.mtype === "conversation"              ? m.message.conversation :
            m.mtype === "extendedTextMessage"       ? m.message.extendedTextMessage.text :
            m.mtype === "imageMessage"              ? m.message.imageMessage.caption :
            m.mtype === "videoMessage"              ? m.message.videoMessage.caption :
            m.mtype === "documentMessage"           ? m.message.documentMessage.caption || "" :
            m.mtype === "audioMessage"              ? m.message.audioMessage.caption || "" :
            m.mtype === "stickerMessage"            ? m.message.stickerMessage.caption || "" :
            m.mtype === "buttonsResponseMessage"    ? m.message.buttonsResponseMessage.selectedButtonId :
            m.mtype === "listResponseMessage"       ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
            m.mtype === "templateButtonReplyMessage"? m.message.templateButtonReplyMessage.selectedId :
            m.mtype === "interactiveResponseMessage"? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
            m.mtype === "messageContextInfo"        ? m.message.buttonsResponseMessage?.selectedButtonId ||
                                                      m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text :
            m.mtype === "reactionMessage"           ? m.message.reactionMessage.text :
            m.mtype === "contactMessage"            ? m.message.contactMessage.displayName :
            m.mtype === "locationMessage"           ? `${m.message.locationMessage.degreesLatitude}, ${m.message.locationMessage.degreesLongitude}` :
            m.mtype === "liveLocationMessage"       ? `${m.message.liveLocationMessage.degreesLatitude}, ${m.message.liveLocationMessage.degreesLongitude}` :
            m.mtype === "pollCreationMessage"       ? m.message.pollCreationMessage.name :
            m.mtype === "viewOnceMessage"           ? (m.message.viewOnceMessage.message.imageMessage?.caption ||
                                                       m.message.viewOnceMessage.message.videoMessage?.caption || "[ViewOnce]") :
            m.mtype === "ephemeralMessage"          ? (m.message.ephemeralMessage.message.conversation ||
                                                       m.message.ephemeralMessage.message.extendedTextMessage?.text || "[Ephemeral]") :
            ""
        )

        const budy   = (typeof m.text == 'string' ? m.text : '')
        const prefix = global.prefa
            ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body)
                ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0]
                : ""
            : global.prefix

        const owner   = JSON.parse(fs.readFileSync('./database/owner.json'))
        const Premium = JSON.parse(fs.readFileSync('./database/premium.json'))
        const isCmd   = body.startsWith(prefix)
        const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
        const args    = body.trim().split(/ +/).slice(1)
        const botNumber  = LangitDev.decodeJid(LangitDev.user.id)
        const isCreator  = [botNumber, ...owner, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const isDev      = [...owner, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const isPremium  = [botNumber, ...Premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const text    = q = args.join(" ")
        const quoted  = m.quoted ? m.quoted : m
        const from    = mek.key.remoteJid
        const sender  = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
        const groupMetadata = m.isGroup ? await LangitDev.groupMetadata(from).catch(e => {}) : ''
        const participants  = m.isGroup ? await groupMetadata.participants : ''
        const groupAdmins   = m.isGroup ? await getGroupAdmins(participants) : ''
        const isBotAdmins   = m.isGroup ? groupAdmins.includes(botNumber) : false
        const isAdmins      = m.isGroup ? groupAdmins.includes(m.sender) : false
        const groupName     = m.isGroup ? groupMetadata.subject : ''
        const pushname      = m.pushName || 'No Name'
        const senderNumber  = sender.split('@')[0]
        const mime          = (quoted.msg || quoted).mimetype || ''
        const time          = moment().tz("Asia/Jakarta").format("HH:mm:ss")
        const todayDateWIB  = new Date().toLocaleDateString('id-ID', {
            timeZone: 'Asia/Jakarta', year: 'numeric', month: 'long', day: 'numeric'
        })

        if (command) {
            console.log(chalk.cyan(
`▢ Mahiru Simpel
 ├─ 📅 ${todayDateWIB}
 ├─ 🕐 ${time}
 ├─ 💬 ${body}
 ├─ 🗣️ ${pushname}
 └─ 👤 ${botNumber}`
            ))
        }

        const Reply = (teks) => {
            LangitDev.sendMessage(from, {
                text: teks,
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                        title: global.botName,
                        body: 'Simple Base Bot Whatsapp ©LangitDev.',
                        thumbnailUrl: 'https://files.catbox.moe/8hvwg4.jpg',
                        sourceUrl: global.sourceCode || 'https://youtube/langitdev4004',
                        mediaType: 1,
                        renderLargerThumbnail: true
                    }
                }
            }, { quoted: m })
        }

        switch (command) {

            case 'ping': {
                const start = Date.now()
                await LangitDev.sendMessage(from, { react: { text: '⚡', key: m.key } })
                const end = Date.now()
                Reply(`*Pong!* ${end - start}ms`)
                break
            }

            case 'runtime': case 'uptime': {
                Reply(`⏱ *Runtime:* ${runtime(process.uptime())}`)
                break
            }

            case 'addpremium': case 'addprem': {
                if (!isCreator) return Reply('Owner only!')
                if (!args[0]) return Reply(`Usage: ${prefix}${command} 62xxx`)
                const number = text.replace(/[^0-9]/g, '')
                const ceknum = await LangitDev.onWhatsApp(number + '@s.whatsapp.net')
                if (!ceknum.length) return Reply('Nomor tidak terdaftar di WhatsApp!')
                Premium.push(number)
                fs.writeFileSync('./database/premium.json', JSON.stringify(Premium))
                Reply(`Berhasil tambah *${number}* ke premium.`)
                break
            }

            case 'delpremium': case 'delprem': {
                if (!isCreator) return Reply('Owner only!')
                if (!args[0]) return Reply(`Usage: ${prefix}${command} 62xxx`)
                const number = text.replace(/[^0-9]/g, '')
                const idx = Premium.indexOf(number)
                if (idx !== -1) {
                    Premium.splice(idx, 1)
                    fs.writeFileSync('./database/premium.json', JSON.stringify(Premium))
                    Reply(`Berhasil hapus *${number}* dari premium.`)
                } else Reply('User tidak ada di daftar premium.')
                break
            }

            case 'public': {
                if (!isCreator) return Reply('Owner only.')
                LangitDev.public = true
                Reply('Mode *Public*')
                break
            }

            case 'private': case 'self': {
                if (!isCreator) return Reply('Owner only.')
                LangitDev.public = false
                Reply('Mode *Self/Private*')
                break
            }

            default: {
                if (budy.startsWith('>') && isCreator) {
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = util.inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) { await m.reply(String(err)) }
                }

                if (budy.startsWith('$') && isCreator) {
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return m.reply(String(err))
                        if (stdout) return m.reply(stdout)
                    })
                }

                const pluginFolder = path.join(__dirname, 'plugins')
                if (fs.existsSync(pluginFolder)) {
                    const pluginFiles = fs.readdirSync(pluginFolder).filter(f => /\.js$/.test(f))
                    for (const plugin of pluginFiles) {
                        const pluginPath = path.join(pluginFolder, plugin)
                        try {
                            const mod = require(pluginPath)
                            if (mod.command && (
                                Array.isArray(mod.command) ? mod.command.includes(command) : mod.command === command
                            )) {
                                await mod.handler({
                                    LangitDev, m, chatUpdate, store,
                                    from, body, command, args, text, prefix,
                                    isCmd, isCreator, isDev, isPremium,
                                    isAdmins, isBotAdmins, sender, senderNumber,
                                    groupMetadata, participants, groupAdmins,
                                    groupName, pushname, mime, time, Reply, quoted
                                })
                            }
                        } catch (e) {
                            console.error(chalk.red(`[Plugin Error] ${plugin}:`), e.message)
                        }
                    }
                }
                break
            }
        }

    } catch (err) {
        console.error(chalk.red('[Mahiru Error]'), util.format(err))
    }
}

const file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.yellow(`[Mahiru] ${__filename} updated, reloading...`))
    delete require.cache[file]
    require(file)
})
