global.botName   = 'Mahiru'
global.developer = 'Langit Dev'
global.prefix    = '.'
global.prefa     = ['.', '!', '#', '/']

global.owner     = [
  '6281234567890'
]

global.ownerName = 'Owner'
global.sourceCode = 'https://github.com'
global.groupLink  = 'https://chat.whatsapp.com'

global.publicX = true 
